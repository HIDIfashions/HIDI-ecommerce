import importlib.util, json, tempfile, unittest
from pathlib import Path

PACKAGE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('installer',PACKAGE/'install.py'); installer=importlib.util.module_from_spec(spec); spec.loader.exec_module(installer)

PRODUCT_LIST='''"use client";\nX\nreturn <><div className={styles.heading}><div><p className={styles.eyebrow}>THE HIDI CATALOGUE</p><h1>Products</h1><p>Create your designs. Build their SKUs. Publish when they are ready.</p></div><Link className={styles.primaryLink} href="/admin/products/new">+ Create new product</Link></div></>;\n'''
ACCESS='''X<Link href="/admin/products" aria-current="page">Products</Link><Link href="/admin/inventory">Inventory</Link>X'''
RECEIVE='''import { appendNewReceiptLines } from "@/lib/admin-products-contract";\nimport { uploadSkuPhotoBatch } from "@/lib/sku-photo-batch";\nX\n        <CreateProductInReceipt disabled={busy || Boolean(photoBusy)} onVariants={(incoming) => {\nX'''

class InstallerTests(unittest.TestCase):
    def repo(self):
        root=Path(tempfile.mkdtemp())
        files={
          'apps/api/prisma/schema.prisma':'model Product {\n}\nmodel ProductVariant {\n}\nmodel StockReceipt {\n}\nmodel ProductVariantImage {\n}\n',
          'apps/web/components/admin-products/product-list.tsx':PRODUCT_LIST,
          'apps/web/components/admin-products/product-access.tsx':ACCESS,
          'apps/web/app/admin/inventory/receive/stock-receipt-client.tsx':RECEIVE,
          'apps/web/lib/admin-products-client.ts':'x', 'apps/web/lib/admin-products-contract.ts':'x', 'apps/web/lib/sku-photo-batch.ts':'x',
        }
        for name,data in files.items(): p=root/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(data)
        return root
    def test_plan_and_apply(self):
        root=self.repo(); changes=installer.plan(root,PACKAGE); self.assertEqual(len(changes),11)
        installer.apply(root,changes)
        self.assertTrue((root/'apps/web/app/admin/import/page.tsx').exists())
        self.assertIn('BulkReceiptCsvImport',(root/'apps/web/app/admin/inventory/receive/stock-receipt-client.tsx').read_text())
        self.assertIn('/admin/import#photos',(root/'apps/web/components/admin-products/product-list.tsx').read_text())
        second=installer.plan(root,PACKAGE); self.assertTrue(all(old==new for _,old,new in second))
    def test_collision_refused(self):
        root=self.repo(); p=root/'apps/web/lib/hidi-spreadsheet.ts'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text('someone else')
        with self.assertRaises(installer.InstallError): installer.plan(root,PACKAGE)
    def test_missing_anchor_refused(self):
        root=self.repo(); (root/'apps/web/components/admin-products/product-list.tsx').write_text('changed')
        with self.assertRaises(installer.InstallError): installer.plan(root,PACKAGE)
    def test_missing_prerequisite_refused(self):
        root=self.repo(); (root/'apps/web/lib/sku-photo-batch.ts').unlink()
        with self.assertRaises(installer.InstallError): installer.plan(root,PACKAGE)

if __name__=='__main__': unittest.main()
