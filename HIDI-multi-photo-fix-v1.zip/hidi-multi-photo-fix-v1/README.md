# HIDI Multi-Photo Fix v1

Target: `HIDIfashions/HIDI-ecommerce`, branch `feature/admin-inventory`.
Prerequisite: stock-receiving/SKU-photo v1 plus Product Management v1 already installed.

## What this fixes

The original receive screen and product editor use a single-file picker and read `files[0]`. The existing multipart endpoint accepts one `file` per request. Merely enabling `multiple` would leave the other selected files unprocessed.

This patch enables multiple selection and sends the files sequentially to the existing endpoint. It changes only:

- ADD `apps/web/lib/sku-photo-batch.ts`.
- PATCH `apps/web/app/admin/inventory/receive/stock-receipt-client.tsx`.
- PATCH `apps/web/components/admin-products/product-editor.tsx`.

There are no backend, schema, migration, `.env`, package, lockfile, Next.js config, layout or CSS file changes. This is a source-code patch, not a database operation or deployment.

## Behaviour

Select 1–8 photos at a time, maximum 5 MiB each (displayed as “5 MB” in the UI). JPEG, PNG, WebP and AVIF are accepted. This limit is deliberately below the existing server's 8 MiB single-photo ceiling and matches the former Product Editor's 5 MiB limit. The whole selection is checked before any upload begins.

The receiving button is labelled **Add SKU photos** or **Add photos (count)**. A progress message reports the current file out of the batch total. The existing **Use for all [colour] sizes** checkbox is retained. Its state is captured for the entire selection. The same batch uploader is used in the Product Editor, including when that editor is opened from the Create Product modal.

Choosing files begins upload immediately; saving or posting a receipt is not required. Photo uploads do not increment inventory. Remain on the page until the batch finishes. Draft receipt quantities and supplier/cost inputs are retained during the photo metadata refresh from Product Management v1. Receipt posting, competing uploads and row removal are disabled while a receiving batch runs.

Each file is a separate request. The batch is NOT an all-or-nothing transaction. If a later file fails, earlier acknowledged files remain saved. The message reports the acknowledged count, the file where processing stopped and how many were not attempted. No automatic retry is performed. A connection failure or server error can occur after bytes or metadata reached the server: check the product's photos before reselecting a file. This patch does not add server-side idempotency, storage rollback, image deletion/reordering, video support, or a new gallery design.

The existing storage configuration, authentication and backend attachment logic are reused unchanged. Successful file selection does not prove that storage is configured; live upload testing is still required.

## About the slow-filesystem warning

This patch does not change filesystem/cache configuration. The warning refers to development-environment filesystem performance and is separate from the file-picker limitation. The receiving page was visibly loaded in the supplied screenshot. Do not delete code, reset the database, reinstall packages, change ports, or move your workspace merely to address photo selection.

## Installation — one step at a time

### 1. Upload the package

On GitHub.com, open `HIDIfashions/HIDI-ecommerce`, select `feature/admin-inventory`, stay at the repository root, and choose **Add file → Upload files**. Upload `HIDI-multi-photo-fix-v1.zip` itself. Commit to the feature branch, not main. Suggested message: `chore: upload multi-photo selection fix`.

### 2. Read-only compatibility check

After upload, run in a spare Codespace terminal:

```bash
cd /workspaces/HIDI-ecommerce &&
PHOTO_FIX_DIR="$(mktemp -d /tmp/hidi-multi-photo.XXXXXX)" &&
git fetch origin feature/admin-inventory &&
git show FETCH_HEAD:HIDI-multi-photo-fix-v1.zip > "$PHOTO_FIX_DIR/update.zip" &&
unzip -q "$PHOTO_FIX_DIR/update.zip" -d "$PHOTO_FIX_DIR" &&
python3 "$PHOTO_FIX_DIR/hidi-multi-photo-fix-v1/install.py" --repo /workspaces/HIDI-ecommerce --check
```

This fetches the uploaded ZIP without merging or overwriting working source. `--check` plans changes but does not apply them. Expected status: **CHECK PASSED — no files or database changed.** Stop and share any `STOP` output instead of forcing an overwrite. The check tests exact known source anchors and stops on conflicting changes. Do not extract the package's `files` directory over your application manually.

### 3. Apply after the compatibility output has been reviewed

First finish/cancel any pending photo upload. Save a legitimate in-progress receipt as a draft when needed; never post fictitious test stock. Stop frontend and backend watchers with Ctrl+C. Run the exact `--apply` command printed by the check. This only changes the three frontend files. It saves backups of the two modified files and a manifest for the added helper in a sibling `HIDI-multi-photo-backup-...` directory outside the repository. Keep that backup.

No migration, seed, `pnpm install`, stash or branch switch is needed. Existing uncommitted HIDI work must not be discarded.

### 4. Type-check in the Codespace

```bash
cd /workspaces/HIDI-ecommerce &&
pnpm --filter @hidi/web exec next typegen &&
pnpm --filter @hidi/web exec tsc --noEmit &&
printf '\nHIDI multi-photo frontend type-check PASSED.\n'
```

Stop on errors. These are code checks, not a full production build or a live storage test. The backend code has not changed, so it does not need regenerating or rebuilding for this patch.

### 5. Restart only one instance of each server

In separate terminals, run the existing `pnpm dev:api` and `pnpm dev:web` from the repository root. Do not launch another instance over an existing server. Keep ports 4000/3000 as configured. Refresh `/admin/inventory/receive` only after preserving any inputs you need. This patch does not add draft-reopening or receipt-editing capabilities.

### 6. Acceptance tests

Use a clearly identified test product and authorised product images. Do not add or post fictitious stock.

1. Note the product's current photo count and a receipt's supplier, cost and accepted-quantity values. Select two supported photos. The picker should allow both; uploads should show progress and then the photo count should rise by two. Verify the saved product gallery, not only the file-picker names.
2. Verify the receipt's supplier, quantities and costs are unchanged, and stock remains unchanged. Do not post the receipt merely to save photos.
3. With the colour checkbox ON, verify attachment to existing sizes of the chosen colour, not another colour. With it OFF on a different test selection, verify SKU-specific scope.
4. Try an oversized, empty or unsupported photo, or nine selected photos. The selection must be rejected before any upload starts.
5. Test the Product Editor's Add photos control with two photos. Verify refreshed thumbnails/counts. The editor currently shows at most four thumbnail previews, even when the saved count is higher.
6. If storage/authentication reports an error, stop and retain the message. Do not share secret keys or `.env` contents. Check saved photos before retrying after a network interruption; the batch is not atomic.

Before committing, review the intended files individually. Do not `git add .` while unrelated source changes, tool directories, ZIP packages and migrations are mixed into the workspace. The source changes are not on GitHub or production merely because the ZIP was uploaded.

## Verification scope

See `TEST-REPORT.md`. The helper/installer tests use mocked boundaries and temporary folders. No live Supabase storage/database, browser, production build or user Codespace was accessed by these tests.

## References

- Next.js development performance: https://nextjs.org/docs/app/guides/local-development
- MDN file input and multiple selection: https://developer.mozilla.org/en-US/docs/Web/HTML/Reference/Elements/input/file
- MDN FormData and multipart boundaries: https://developer.mozilla.org/en-US/docs/Web/API/XMLHttpRequest_API/Using_FormData_Objects
- Git fetch: https://git-scm.com/docs/git-fetch
- Git show: https://git-scm.com/docs/git-show
- GitHub browser uploads: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
