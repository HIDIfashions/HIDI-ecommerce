#!/usr/bin/env python3
"""Conservative, offline installer. No Git writes, commands, dependencies or database calls."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tempfile
from datetime import datetime, timezone

PACKAGE = Path(__file__).resolve().parent
class InstallError(RuntimeError): pass

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def safe_target(root: Path, name: str) -> Path:
    relative = PurePosixPath(name)
    if relative.is_absolute() or not relative.parts or any(part in ('.', '..', '') for part in relative.parts) or '\\' in name:
        raise InstallError(f'Unsafe package path: {name}')
    target = root.joinpath(*relative.parts)
    for candidate in [target, *target.parents]:
        if candidate == root.parent: break
        if candidate.is_symlink(): raise InstallError(f'Symlink refused: {candidate}')
    if target.exists() and not target.is_file(): raise InstallError(f'Expected a regular file: {name}')
    return target

def edit_text(original: bytes, entry: dict) -> bytes:
    try: text = original.decode('utf-8')
    except UnicodeDecodeError as error: raise InstallError(f'Not UTF-8: {entry["path"]}') from error
    # Preserve CRLF rather than mixing line endings into the operator's files.
    crlf = "\r\n" in text
    if crlf and "\n" in text.replace("\r\n", ""):
        raise InstallError("Mixed line endings need review: " + entry["path"])
    for edit in entry['edits']:
        before, after = edit['before'], edit['after']
        if crlf: before, after = before.replace('\n', '\r\n'), after.replace('\n', '\r\n')
        if text.count(after) == 1:
            continue  # Already applied, including when unrelated lines changed later.
        if text.count(before) != 1:
            raise InstallError(f'Patch context missing or ambiguous: {entry["path"]}\nExpected a single occurrence of: {before[:100]!r}\nNo files were changed. Share this result; do not overwrite the file.')
        text = text.replace(before, after, 1)
    return text.encode('utf-8')

def plan(root: Path, package: Path = PACKAGE):
    manifest = json.loads((package/'manifest.json').read_text())
    schema = safe_target(root, 'apps/api/prisma/schema.prisma')
    if not schema.is_file(): raise InstallError('The selected directory is not the HIDI repository.')
    schema_text = schema.read_text()
    for required in ('model StockReceipt {', 'model ProductVariantImage {', 'model Product {', 'model ProductVariant {'):
        if required not in schema_text: raise InstallError('Apply the stock-receiving/SKU-photo update first. Missing schema prerequisite: '+required)
    for required in ('apps/web/lib/admin-auth.ts', 'apps/api/src/prisma/prisma.module.ts', 'apps/web/app/api/admin/inventory/[variantId]/images/route.ts'):
        if not safe_target(root, required).is_file(): raise InstallError('Missing prerequisite: '+required)
    changes = []; seen = set()
    for entry in manifest['files']:
        name = entry['path']
        if name in seen: raise InstallError('Duplicate package target: '+name)
        seen.add(name)
        source = safe_target(package/'files', name)
        data = source.read_bytes()
        if digest(data) != entry['sha256']: raise InstallError('Package integrity check failed: '+name)
        target = safe_target(root, name)
        old = target.read_bytes() if target.exists() else None
        if old is not None and old != data:
            raise InstallError('New-file collision; existing work will not be overwritten: '+name)
        changes.append((name, old, data))
    for entry in manifest['patches']:
        name = entry['path']
        if name in seen: raise InstallError('Duplicate package target: '+name)
        seen.add(name)
        target = safe_target(root, name)
        if not target.exists(): raise InstallError('Missing shared file: '+name)
        original = target.read_bytes(); data = edit_text(original, entry)
        changes.append((name, original, data))
    return changes

def atomic_write(target: Path, data: bytes, mode: int = 0o644):
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.hidi-multi-photo-', dir=target.parent)
    try:
        with os.fdopen(fd, 'wb') as output:
            output.write(data); output.flush(); os.fsync(output.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, target)
    finally:
        if os.path.exists(temporary): os.unlink(temporary)

def apply(root: Path, changes):
    changed = [(n, old, new) for n, old, new in changes if old != new]
    if not changed: print('Already installed. No files changed.'); return None
    # Sibling directory, outside the repository. No environment files are copied.
    backup = Path(tempfile.mkdtemp(prefix='HIDI-multi-photo-backup-', dir=root.parent))
    records = []
    for name, old, new in changed:
        target = safe_target(root, name)
        mode = stat.S_IMODE(target.stat().st_mode) if old is not None else 0o644
        if old is not None:
            saved = backup/'originals'/name; saved.parent.mkdir(parents=True, exist_ok=True); saved.write_bytes(old)
        records.append({'path':name,'existed':old is not None,'before':digest(old) if old is not None else None,'after':digest(new),'mode':mode})
    (backup/'backup.json').write_text(json.dumps({'repository':str(root),'createdAt':datetime.now(timezone.utc).isoformat(),'files':records},indent=2)+'\n')
    for name, old, new in changed:
        target = safe_target(root,name)
        current = target.read_bytes() if target.exists() else None
        if current != old: raise InstallError('File changed during preflight; nothing applied: '+name)
    written = []
    try:
        for (name, old, new), record in zip(changed, records):
            target = safe_target(root, name); atomic_write(target,new,record['mode']); written.append((name,old,record['mode']))
    except Exception:
        for name, old, mode in reversed(written):
            target = safe_target(root,name)
            if old is None: target.unlink(missing_ok=True)
            else: atomic_write(target,old,mode)
        raise
    print(f'APPLIED: {len(changed)} files. Backup: {backup}')
    print('No database, environment, dependency, Git commit, stash or branch changes were made.')
    return backup

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    mode = parser.add_mutually_exclusive_group(required=True); mode.add_argument('--check',action='store_true');mode.add_argument('--apply',action='store_true')
    args = parser.parse_args(); root=args.repo.absolute()
    if root.is_symlink(): raise InstallError('Repository symlinks are not supported.')
    root=root.resolve()
    if not root.is_dir(): raise InstallError('Repository directory does not exist.')
    changes=plan(root)
    for name, old, new in changes:
        print(('UNCHANGED' if old==new else 'ADD' if old is None else 'PATCH')+'  '+name)
    if args.check:
        print('\nCHECK PASSED — no files or database changed.')
        print(f'After stopping web/API watchers, apply with:\npython3 {PACKAGE / "install.py"} --repo {root} --apply')
    else: apply(root,changes)

if __name__ == '__main__':
    try: main()
    except (InstallError, OSError, ValueError, KeyError) as error:
        print('STOP: '+str(error),file=sys.stderr);sys.exit(1)
