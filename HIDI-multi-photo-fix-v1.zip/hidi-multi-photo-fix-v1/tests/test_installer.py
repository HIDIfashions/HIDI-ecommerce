"""Offline tests. All writes are confined to temporary directories."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location("installer", PACKAGE / "install.py")
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)

class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name) / "repo"
        self.root.mkdir()
        self.manifest = json.loads((PACKAGE / "manifest.json").read_text())
        self.write("apps/api/prisma/schema.prisma", "\n".join(["model StockReceipt {", "model ProductVariantImage {", "model Product {", "model ProductVariant {"]))
        for name in ("apps/web/lib/admin-auth.ts", "apps/api/src/prisma/prisma.module.ts", "apps/web/app/api/admin/inventory/[variantId]/images/route.ts"):
            self.write(name, "// prerequisite stub - test only\n")
        # Source anchors are the exact text used by the compatibility installer.
        # Construct a test file with each complete original anchor, dropping any
        # anchor included inside another, so validation reflects unique matches.
        for entry in self.manifest["patches"]:
            originals = [e["before"] for e in entry["edits"]]
            top = [s for s in originals if not any(s != other and s in other for other in originals)]
            self.write(entry["path"], "\n// unrelated source preserved\n".join(top))
        self.write(".env.local", "KEEP_PRIVATE=not-a-real-key\n")
        self.write("apps/web/next.config.ts", "// preserve config\n")
        self.write("package.json", '{"private":true}\n')
    def tearDown(self): self.temporary.cleanup()
    def write(self, name, text):
        p = self.root / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text)
    def snapshot(self):
        return {p.relative_to(self.root).as_posix(): p.read_bytes() for p in self.root.rglob("*") if p.is_file()}
    def test_preflight_is_read_only(self):
        before = self.snapshot()
        plan = installer.plan(self.root, PACKAGE)
        self.assertEqual(len(plan), 3)
        self.assertEqual(before, self.snapshot())
    def test_apply_and_backup(self):
        before = self.snapshot()
        backup = installer.apply(self.root, installer.plan(self.root, PACKAGE))
        self.assertEqual(backup.parent, self.root.parent)
        records = json.loads((backup / "backup.json").read_text())["files"]
        self.assertEqual(len(records), 3)
        for record in records:
            name = record["path"]
            if record["existed"]:
                self.assertEqual((backup / "originals" / name).read_bytes(), before[name])
            self.assertEqual(hashlib.sha256((self.root/name).read_bytes()).hexdigest(), record["after"])
        for untouched in (".env.local", "apps/web/next.config.ts", "package.json"):
            self.assertEqual((self.root / untouched).read_bytes(), before[untouched])
    def test_idempotent(self):
        installer.apply(self.root, installer.plan(self.root, PACKAGE))
        before = self.snapshot()
        plan = installer.plan(self.root, PACKAGE)
        self.assertTrue(all(old == new for _, old, new in plan))
        self.assertIsNone(installer.apply(self.root, plan))
        self.assertEqual(before, self.snapshot())
    def test_rejects_changed_anchor(self):
        path = self.manifest["patches"][0]["path"]
        p = self.root / path
        p.write_text(p.read_text().replace('async function uploadPhoto(', 'async function userUploadPhoto('))
        before = self.snapshot()
        with self.assertRaises(installer.InstallError): installer.plan(self.root, PACKAGE)
        self.assertEqual(before, self.snapshot())
    def test_rejects_new_file_collision(self):
        self.write(self.manifest["files"][0]["path"], '// custom unrelated helper\n')
        before = self.snapshot()
        with self.assertRaises(installer.InstallError): installer.plan(self.root, PACKAGE)
        self.assertEqual(before, self.snapshot())
    def test_missing_prerequisite(self):
        (self.root / 'apps/api/prisma/schema.prisma').unlink()
        with self.assertRaises(installer.InstallError): installer.plan(self.root, PACKAGE)
    def test_symlink_rejected(self):
        p = self.root / self.manifest["patches"][0]["path"]
        p.unlink(); p.symlink_to(self.root / 'package.json')
        with self.assertRaises(installer.InstallError): installer.plan(self.root, PACKAGE)
    def test_crlf_is_preserved(self):
        for entry in self.manifest["patches"]:
            p = self.root / entry["path"]
            p.write_bytes(p.read_bytes().replace(b'\n', b'\r\n'))
        plan = installer.plan(self.root, PACKAGE)
        for _, old, new in plan:
            if old is not None:
                self.assertNotIn(b'\n', new.replace(b'\r\n', b''))
    def test_race_rejected(self):
        plan = installer.plan(self.root, PACKAGE)
        self.write(self.manifest['patches'][0]['path'], '// changed after preflight\n')
        before = self.snapshot()
        with self.assertRaises(installer.InstallError): installer.apply(self.root, plan)
        self.assertEqual(before, self.snapshot())
    def test_rolls_back_on_write_failure(self):
        plan = installer.plan(self.root, PACKAGE)
        before = self.snapshot(); original = installer.atomic_write; writes = 0
        def fail_second(*args, **kwargs):
            nonlocal writes
            writes += 1
            if writes == 2: raise OSError('simulated disk error')
            return original(*args, **kwargs)
        with patch.object(installer, 'atomic_write', side_effect=fail_second):
            with self.assertRaises(OSError): installer.apply(self.root, plan)
        self.assertEqual(before, self.snapshot())

if __name__ == '__main__': unittest.main(verbosity=2)
