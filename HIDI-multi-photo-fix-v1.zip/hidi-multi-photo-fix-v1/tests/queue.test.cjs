// No network/database calls: fetch is replaced by an in-memory stub.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { createRequire } = require('node:module');
let ts;
const repoFlag = process.argv.indexOf('--repo');
const root = repoFlag >= 0 ? path.resolve(process.argv[repoFlag + 1]) : process.cwd();
for (const anchor of [path.join(root, 'apps/web/package.json'), path.join(root, 'apps/api/package.json'), __filename]) {
  try { ts = createRequire(anchor)('typescript'); break; } catch {}
}
if (!ts) throw new Error('TypeScript not found. Run from the HIDI repository or pass --repo /workspaces/HIDI-ecommerce.');
const file = path.join(__dirname, '../files/apps/web/lib/sku-photo-batch.ts');
const source = fs.readFileSync(file, 'utf8');
const js = ts.transpileModule(source, {compilerOptions:{target:ts.ScriptTarget.ES2022, module:ts.ModuleKind.CommonJS}, reportDiagnostics:true});
assert.equal((js.diagnostics||[]).filter(d=>d.category===ts.DiagnosticCategory.Error).length, 0);
const context = { exports:{}, require, File, FormData, AbortController, setTimeout, clearTimeout, fetch:undefined };
vm.runInNewContext(js.outputText, context, {filename:file});
const {uploadSkuPhotoBatch, validatePhotoSelection, PhotoBatchError} = context.exports;
const photo = (name, type='image/jpeg', size=4) => new File([new Uint8Array(size)], name, {type});
let passed=0;
async function test(name, fn) { await fn(); passed++; console.log('PASS', name); }
(async()=>{
 await test('empty selection rejected',()=>assert.throws(()=>validatePhotoSelection([]), /at least one/));
 await test('more than eight rejected',()=>assert.throws(()=>validatePhotoSelection(Array.from({length:9},(_,i)=>photo(i+'.jpg'))), /up to 8/));
 await test('zero bytes rejected',()=>assert.throws(()=>validatePhotoSelection([photo('empty.jpg','image/jpeg',0)]), /non-empty/));
 await test('oversized rejected',()=>assert.throws(()=>validatePhotoSelection([photo('large.jpg','image/jpeg',5*1024*1024+1)]), /5 MB/));
 await test('size boundary accepted',()=>validatePhotoSelection([photo('limit.jpg','image/jpeg',5*1024*1024)]));
 await test('SVG and video rejected',()=>{
   assert.throws(()=>validatePhotoSelection([photo('a.svg','image/svg+xml')]), /JPEG/);
   assert.throws(()=>validatePhotoSelection([photo('a.mp4','video/mp4')]), /JPEG/);
 });
 await test('four supported formats accepted',()=>validatePhotoSelection(['image/jpeg','image/png','image/webp','image/avif'].map((t,i)=>photo(i+'.img',t))));
 await test('validate ALL files before first request',async()=>{
   let calls=0;context.fetch=async()=>{calls++;return {ok:true,json:async()=>({})};};
   await assert.rejects(uploadSkuPhotoBatch({variantId:'sku',files:[photo('valid.jpg'),photo('bad.svg','image/svg+xml')],applyToColor:true}),/Nothing was uploaded/);
   assert.equal(calls,0);
 });
 await test('sequential requests, all files, stable scope, multipart boundary',async()=>{
   let active=0,maxActive=0;const names=[],progress=[],paths=[];
   context.fetch=async(url,init)=>{
     active++;maxActive=Math.max(maxActive,active); paths.push(url);names.push(init.body.get('file').name);
     assert.equal(init.body.get('applyToColor'),'true');assert.equal(init.headers,undefined);
     await new Promise(r=>setTimeout(r,2));active--;return {ok:true,json:async()=>({photoCount:names.length})};
   };
   const result=await uploadSkuPhotoBatch({variantId:'sku/a',files:[photo('front.jpg'),photo('back.jpg'),photo('detail.jpg')],applyToColor:true,onProgress:p=>progress.push(p.current)});
   assert.equal(result.uploaded,3);assert.equal(maxActive,1);assert.deepEqual(names,['front.jpg','back.jpg','detail.jpg']);assert.deepEqual(progress,[1,2,3]);
   assert.equal(paths[0],'/api/admin/inventory/sku%2Fa/images');
 });
 await test('per-SKU false scope preserved',async()=>{
   context.fetch=async(_,i)=>{assert.equal(i.body.get('applyToColor'),'false');return {ok:true,json:async()=>({})};};
   const result=await uploadSkuPhotoBatch({variantId:'a',files:[photo('one.jpg')],applyToColor:false});assert.equal(result.uploaded,1);
 });
 await test('server failure stops batch and reports saved count',async()=>{
   let calls=0;context.fetch=async()=>{calls++;return calls===1?{ok:true,json:async()=>({})}:{ok:false,json:async()=>({message:'Storage unavailable'})};};
   await assert.rejects(uploadSkuPhotoBatch({variantId:'a',files:[photo('1.jpg'),photo('2.jpg'),photo('3.jpg')],applyToColor:true}),e=>{
     assert(e instanceof PhotoBatchError);assert.equal(e.uploaded,1);assert.equal(e.notAttempted,1);assert.equal(e.failedFile,'2.jpg');assert.equal(e.uncertain,true);assert.match(e.message,/Storage unavailable/);return true;
   });assert.equal(calls,2);
 });
 await test('network failure is ambiguous and never retried',async()=>{
   let calls=0;context.fetch=async()=>{calls++;throw new Error('offline');};
   await assert.rejects(uploadSkuPhotoBatch({variantId:'a',files:[photo('1.jpg'),photo('2.jpg')],applyToColor:true}),e=>e.uncertain&&e.uploaded===0&&/may already/.test(e.message));assert.equal(calls,1);
 });
 await test('invalid success JSON is not accepted as a save',async()=>{
   context.fetch=async()=>({ok:true,json:async()=>{throw new Error('invalid');}});
   await assert.rejects(uploadSkuPhotoBatch({variantId:'a',files:[photo('1.jpg')],applyToColor:true}),e=>e.uncertain&&e.uploaded===0);
 });
 await test('empty SKU cannot issue network request',async()=>{
   context.fetch=async()=>{throw new Error('must not run');};
   await assert.rejects(uploadSkuPhotoBatch({variantId:' ',files:[photo('1.jpg')],applyToColor:true}),/Choose a SKU/);
 });
 await test('selection snapshotted before UI can change it',async()=>{
   const files=[photo('1.jpg'),photo('2.jpg')],names=[];
   context.fetch=async(_,i)=>{names.push(i.body.get('file').name);files.splice(0);return {ok:true,json:async()=>({})};};
   const result=await uploadSkuPhotoBatch({variantId:'a',files,applyToColor:true});assert.equal(result.uploaded,2);assert.deepEqual(names,['1.jpg','2.jpg']);
 });
 console.log(`${passed} queue tests passed. Network and database mocked.`);
})().catch(e=>{console.error(e);process.exitCode=1;});
