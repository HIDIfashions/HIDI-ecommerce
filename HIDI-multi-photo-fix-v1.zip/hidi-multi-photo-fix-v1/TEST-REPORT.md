# HIDI Multi-Photo Fix v1 — Verification report

Prepared 18 September 2026. No changes were made to the user's GitHub branch, Codespace, Supabase database or storage during these checks.

## Inspected baseline

- Stock-receiving/SKU-photo archive in the connected repository, blob `06fa5bcfdc013e50e7590a8992b97008d5b66739`.
- Product Management v1 archive supplied in this conversation; the known receipt edits were applied locally to reconstruct the installed receiving component.
- The extracted receipt and image-route entries were verified against their ZIP length and CRC32 values. Source retrieval used the GitHub connector because those updates are still packaged as ZIPs on the remote branch.
- The actual current Codespace may have further uncommitted edits. The supplied installer therefore rechecks unique patch contexts before modifying files.

## Confirmed cause in the installed packages

Receive Stock uses `const file = event.target.files?.[0]` with no `multiple` attribute. Its handler accepts one `File`. The Product Editor has the same single-file design. The Next.js multipart endpoint obtains `form.get("file")` and accepts one image per request. Consequently the fix must enumerate a selection, not simply add the HTML attribute.

## Passed locally

- 15 upload-queue tests, with mocked fetch: empty selection, 9-file limit, zero bytes, oversized/boundary file, SVG/video rejection, supported formats, whole-batch validation before requests, sequential ordering, multipart boundary left to the browser, colour/SKU scope, partial failure counts, interrupted request uncertainty/no retry, malformed response, empty SKU, and snapshotting the selection.
- 10 installer tests: read-only preflight, backup content and untouched sensitive/config files, idempotency, changed anchor rejection, new-file collision rejection, missing prerequisite, symlink rejection, CRLF preservation, concurrent-source-change rejection, and rollback following simulated write failure.
- Strict TypeScript check of the standalone uploader helper with the DOM/ES2022 libraries.
- TSX syntax/transpilation checks of both patched components.
- Integration against the reconstructed real baseline: preflight, apply and second-run idempotency. The resulting files matched the intended patched files, both inputs had `multiple`, and neither component retained `files?.[0]`.

## Not yet verified

The user's full Next.js project type-check/build, browser behaviour, live API/storage authentication, object uploads, metadata persistence, product gallery display, and preservation of actual receipt inputs require the Codespace and browser acceptance tests in README.md. Local syntax tests are not a substitute for full frontend type-checking. Mocked fetch tests do not prove live uploads succeed.

## Deliberate boundaries

Three frontend files only. No migrations, schema/stock changes, package installs, database queries, environment changes, Next.js cache changes or automatic Git operations in the installer. Eight files per selection, 5 MiB per file. Sequential requests, not an atomic batch; no automatic retries or new server-side idempotency/rollback.
