"""Offline installer tests. Uses temporary fixtures, never a real project or database."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

PKG=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('hidi_installer',PKG/'install.py')
installer=importlib.util.module_from_spec(spec);spec.loader.exec_module(installer)

class InstallerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)/'HIDI-ecommerce';self.root.mkdir()
        self.manifest=json.loads((PKG/'manifest.json').read_text())
        self.put('apps/api/prisma/schema.prisma','model StockReceipt {\n}\nmodel ProductVariantImage {\n}\nmodel Product {\n}\nmodel ProductVariant {\n}\n// parallel rewards schema preserved\n')
        for name in ['apps/web/lib/admin-auth.ts','apps/api/src/prisma/prisma.module.ts','apps/web/app/api/admin/inventory/[variantId]/images/route.ts']:
            self.put(name,'// existing prerequisite\n')
        for entry in self.manifest['patches']:
            self.put(entry['path'],'// unrelated work must survive\n'+'\n'.join(e['before'] for e in entry['edits'])+'\n// end of existing file\n')
        for name in ['.env','apps/web/.env.local','apps/web/app/layout.tsx','apps/web/next.config.ts','package.json','pnpm-lock.yaml','prisma.config.ts','apps/api/prisma/migrations/old/migration.sql']:
            self.put(name,'keep this exact local work\n')
    def tearDown(self): self.tmp.cleanup()
    def put(self,name,text):
        p=self.root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);return p
    def snapshot(self): return {str(p.relative_to(self.root)):p.read_bytes() for p in self.root.rglob('*') if p.is_file() and not p.is_symlink()}
    def apply(self):
        with contextlib.redirect_stdout(io.StringIO()): return installer.apply(self.root,installer.plan(self.root,PKG))
    def test_check_is_read_only(self):
        before=self.snapshot();plan=installer.plan(self.root,PKG)
        self.assertEqual(len(plan),len(self.manifest['files'])+3);self.assertEqual(before,self.snapshot())
        self.assertEqual(list(self.root.parent.glob('HIDI-products-backup-*')),[])
    def test_apply_preserves_configuration_and_schema(self):
        before=self.snapshot();backup=self.apply();self.assertTrue((backup/'backup.json').is_file())
        changed={e['path'] for e in self.manifest['patches']}
        for name,data in before.items():
            if name not in changed:self.assertEqual((self.root/name).read_bytes(),data,name)
        for name in changed:
            self.assertEqual((backup/'originals'/name).read_bytes(),before[name]);self.assertIn('unrelated work must survive',(self.root/name).read_text())
    def test_repeat_apply_is_idempotent(self):
        self.apply();before=self.snapshot();self.assertIsNone(self.apply());self.assertEqual(before,self.snapshot());self.assertEqual(len(list(self.root.parent.glob('HIDI-products-backup-*'))),1)
    def test_drift_blocks_every_write(self):
        entry=self.manifest['patches'][-1];target=self.root/entry['path'];target.write_text(target.read_text().replace(entry['edits'][-1]['before'],'// incompatible receiver'))
        before=self.snapshot()
        with self.assertRaises(installer.InstallError):self.apply()
        self.assertEqual(before,self.snapshot())
    def test_new_file_collision_is_not_overwritten(self):
        self.put(self.manifest['files'][0]['path'],'other feature owns this file');before=self.snapshot()
        with self.assertRaises(installer.InstallError):self.apply()
        self.assertEqual(before,self.snapshot())
    def test_missing_stock_prerequisite_is_blocked(self):
        self.put('apps/api/prisma/schema.prisma','model Product {}')
        with self.assertRaises(installer.InstallError):installer.plan(self.root,PKG)
    def test_symlink_parent_is_refused(self):
        parent=self.root/'apps/web/components';parent.mkdir(parents=True,exist_ok=True)
        outside=Path(self.tmp.name)/'outside';outside.mkdir();(parent/'admin-products').symlink_to(outside,target_is_directory=True)
        with self.assertRaises(installer.InstallError):installer.plan(self.root,PKG)
        self.assertEqual(list(outside.iterdir()),[])
    def test_payload_integrity_is_checked(self):
        package=Path(self.tmp.name)/'package';shutil.copytree(PKG,package)
        (package/'files'/self.manifest['files'][0]['path']).write_text('corrupt')
        with self.assertRaises(installer.InstallError):installer.plan(self.root,package)
    def test_path_traversal_is_refused(self):
        for name in ['../outside','/etc/passwd','apps/../../outside','apps\\evil']:
            with self.assertRaises(installer.InstallError):installer.safe_target(self.root,name)
    def test_failure_rolls_back_written_files(self):
        before=self.snapshot();original=installer.atomic_write;count=0;fail_at=len(self.manifest['files'])+2
        def failing(*args,**kwargs):
            nonlocal count;count+=1
            if count==fail_at:raise OSError('simulated disk failure')
            return original(*args,**kwargs)
        with patch.object(installer,'atomic_write',side_effect=failing):
            with self.assertRaises(OSError):self.apply()
        self.assertEqual(before,self.snapshot())
    def test_crlf_line_endings_are_preserved(self):
        entry=self.manifest['patches'][0];target=self.root/entry['path'];target.write_bytes(target.read_bytes().replace(b'\n',b'\r\n'))
        self.apply();self.assertNotIn(b'\n',target.read_bytes().replace(b'\r\n',b''))
    def test_duplicate_context_is_blocked(self):
        entry=self.manifest['patches'][0];target=self.root/entry['path'];target.write_text(target.read_text()+'\n'+entry['edits'][0]['before'])
        with self.assertRaises(installer.InstallError):installer.plan(self.root,PKG)

if __name__=='__main__':unittest.main(verbosity=2)
