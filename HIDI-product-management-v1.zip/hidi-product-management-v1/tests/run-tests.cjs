/* Unit/contract tests use mocked framework/database boundaries; no external service is called. */
const { test, after } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs'); const path = require('node:path');
const packageRoot = path.resolve(__dirname, '..');
const repo = process.argv.includes('--repo') ? process.argv[process.argv.indexOf('--repo') + 1] : process.cwd();
const ts = require(process.env.HIDI_TYPESCRIPT || require.resolve('typescript', { paths: [path.join(repo,'apps/api'),repo] }));
const files = path.join(packageRoot,'files');
const originalKey = process.env.ADMIN_API_KEY;
process.env.ADMIN_API_KEY = 'unit-test-only-hidi-key';
after(() => { if (originalKey === undefined) delete process.env.ADMIN_API_KEY; else process.env.ADMIN_API_KEY=originalKey; });
const noop = () => () => {};
const nest = { Injectable: noop, Controller: noop, Get: noop, Post: noop, Patch: noop, UseGuards: noop, Body: noop, Param: noop, Query: noop, Module: noop };
for (const [name,status] of Object.entries({ BadRequestException:400, ConflictException:409, NotFoundException:404, UnauthorizedException:401 })) nest[name]=class extends Error { constructor(message){super(message);this.status=status;} getStatus(){return this.status;} };
function loader(extras={}) {
 const cache=new Map();
 return function load(file) {
  file=path.resolve(file);if(cache.has(file))return cache.get(file).exports;
  const source=fs.readFileSync(file,'utf8');
  const result=ts.transpileModule(source,{fileName:file,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,experimentalDecorators:true,emitDecoratorMetadata:true,jsx:ts.JsxEmit.ReactJSX}});
  assert.equal((result.diagnostics??[]).filter(d=>d.category===ts.DiagnosticCategory.Error).length,0,file+' syntax');
  const mod={exports:{}};cache.set(file,mod);
  function req(name) {
    if(Object.hasOwn(extras,name))return extras[name];
    if(name==='@nestjs/common')return nest;
    if(name.endsWith('/prisma/prisma.service.js'))return {PrismaService:class {}};
    if(name.startsWith('.'))return load(path.resolve(path.dirname(file),name.replace(/\.js$/,'.ts')));
    return require(name);
  }
  new Function('require','module','exports','fetch',result.outputText)(req,mod,mod.exports,extras.fetch ?? (()=>{throw new Error('Unexpected network request');}));
  return mod.exports;
 };
}
const load=loader();
const apiPath=path.join(files,'apps/api/src/admin/products');
const input=load(path.join(apiPath,'product-input.ts'));
const contract=load(path.join(files,'apps/web/lib/admin-products-contract.ts'));
const {AdminProductsService}=load(path.join(apiPath,'admin-products.service.ts'));
const {AdminProductsGuard}=load(path.join(apiPath,'admin-products.guard.ts'));
const valid=()=>({name:'Meera Cotton Kurta',colors:[{name:'Maroon',hex:'#800000'},{name:'Navy',hex:null}],sizes:['M','L','XL','XXL'],pricePaise:149900,mrpPaise:179900,weightGrams:250,collectionIds:[],requestId:'b16fea98-9025-42c1-9d01-2775cf584b1c'});

function product(overrides={}) {
 return {id:'product_demo',name:'Meera Cotton Kurta',slug:'meera-cotton-kurta',status:'DRAFT',categoryId:null,category:null,shortDescription:null,description:null,fabric:null,care:null,createdAt:new Date('2026-09-17T10:00:00.000Z'),updatedAt:new Date('2026-09-17T10:00:00.000Z'),images:[],collections:[],variants:[{id:'variant_m',productId:'product_demo',sku:'HIDI-DEMO-MAROON-M',color:'Maroon',colorHex:'#800000',size:'M',pricePaise:149900,mrpPaise:179900,weightGrams:250,active:true,images:[],inventory:{onHand:9,reserved:2,safetyStock:1,reorderLevel:5}}],...overrides};
}
function fake(initial=null) {
 let saved=initial?structuredClone(initial):null;const calls=[];let txCount=0;let retries=0;
 const read=()=>saved?structuredClone(saved):null;
 const db={
  product:{
   async findUnique({where}){return saved && where.id===saved.id?read():null;},
   async create({data}){calls.push(['create',structuredClone(data)]);saved={...product(),...data,createdAt:new Date(),updatedAt:new Date(),category:null,images:[],collections:data.collections.create.map(c=>({...c,collection:{id:c.collectionId}})),variants:data.variants.create.map((v,i)=>({...v,id:'new_'+i,productId:data.id,images:[],inventory:{...v.inventory.create}}))};return read();},
   async update({where,data}){assert.equal(where.id,saved.id);calls.push(['product.update',structuredClone(data)]);const {collections, ...rest}=data;saved={...saved,...rest};if(collections)saved.collections=collections.create.map(c=>({...c,collection:{id:c.collectionId}}));return read();},
  },
  productVariant:{
   async create({data}){calls.push(['variant.create',structuredClone(data)]);const v={...data,id:'added_'+saved.variants.length,images:(data.images?.create??[]).map((p,i)=>({...p,id:'photo_'+i})),inventory:{...data.inventory.create}};saved.variants.push(v);return structuredClone(v);},
   async update({where,data}){calls.push(['variant.update',structuredClone(data)]);const v=saved.variants.find(v=>v.id===where.id);Object.assign(v,data);return structuredClone(v);},
  },
  category:{async findFirst({where}){return where.id==='bad'?null:{id:where.id,active:true};}},
  collection:{async count({where}){return where.id.in.includes('bad')?0:where.id.in.length;}},
  inventory:{update(){throw new Error('Product management must not mutate existing stock');},delete(){throw new Error('Inventory deletion is forbidden');}},
  async $queryRaw(){calls.push(['lock']);return [];},
  async $transaction(fn,options){txCount++;assert.equal(options.isolationLevel,'Serializable');if(retries-->0)throw Object.assign(new Error('retry'),{code:'P2034'});const old=read();try{return await fn(db);}catch(e){saved=old;throw e;}},
 };
 return {db,calls,get saved(){return read();},get txCount(){return txCount;},setRetries(n){retries=n;}};
}
const version=p=>p.updatedAt.toISOString();
const expectStatus=status=>e=>e.status===status;

test('create normalises fields and creates an 8-combination matrix',()=>{const p=input.parseCreate(valid());assert.equal(p.slug,'meera-cotton-kurta');assert.equal(p.colors.length*p.sizes.length,8);assert.equal(p.categoryId,null);});
test('create cannot accept publication status',()=>assert.throws(()=>input.parseCreate({...valid(),status:'ACTIVE'}),/Unsupported field/));
for(const name of ['onHand','reserved','initialStock','unitCostPaise','sku'])test('create refuses '+name,()=>assert.throws(()=>input.parseCreate({...valid(),[name]:100}),/Unsupported field/));
for(const amount of [0,-1,1.5,NaN,Infinity,100000001,'149900'])test('price validator refuses '+String(amount),()=>assert.throws(()=>input.parseCreate({...valid(),pricePaise:amount})));
test('MRP cannot be below selling price',()=>assert.throws(()=>input.parseCreate({...valid(),mrpPaise:10000}),/exceed MRP/));
test('colour names are case/space insensitive for duplicates',()=>assert.throws(()=>input.parseCreate({...valid(),colors:[{name:'Maroon'},{name:'  MAROON '}] }),/Duplicate/));
test('colour token collisions are rejected',()=>assert.throws(()=>input.parseCreate({...valid(),colors:[{name:'Blue/Grey'},{name:'Blue Grey'}]}),/Duplicate/));
test('size aliases differing only in case cannot duplicate',()=>assert.throws(()=>input.parseCreate({...valid(),sizes:['xl','XL']}),/Duplicate/));
test('more than 200 combinations are rejected',()=>assert.throws(()=>input.parseCreate({...valid(),colors:Array.from({length:20},(_,n)=>({name:'Colour '+n})),sizes:Array.from({length:15},(_,n)=>'Size '+n)}),/200/));
test('malformed request UUID is rejected',()=>assert.throws(()=>input.parseCreate({...valid(),requestId:'not-a-uuid'}),/request ID/i));
test('invalid colour hex is rejected',()=>assert.throws(()=>input.parseCreate({...valid(),colors:[{name:'Navy',hex:'blue'}]}),/hex/));
test('invalid product URL is rejected',()=>assert.throws(()=>input.parseCreate({...valid(),slug:'../secret'}),/Product URL/));
test('metadata edit cannot mutate slug, stock or status',()=>{for(const key of ['slug','status','onHand'])assert.throws(()=>input.parseEdit({name:'Dress',expectedUpdatedAt:version(product()),[key]:'value'}),/Unsupported field/);});
test('variant identity and foreign product ID cannot be patched',()=>{for(const key of ['sku','size','color','productId'])assert.throws(()=>input.parseVariantEdit({pricePaise:100,mrpPaise:200,active:true,expectedUpdatedAt:version(product()),[key]:'value'}),/Unsupported field/);});
test('variant enabled flag is strictly boolean',()=>assert.throws(()=>input.parseVariantEdit({pricePaise:100,mrpPaise:200,active:'false',expectedUpdatedAt:version(product())}),/true or false/));
test('revision must be a valid ISO date',()=>assert.throws(()=>input.parseStatus({status:'ACTIVE',expectedUpdatedAt:'not-a-date'})));
test('rupee conversion is exact for two decimal places',()=>{assert.equal(contract.rupeesToPaise('1499.99'),149999);assert.equal(contract.rupeesToPaise('0.01'),1);assert.equal(contract.rupeesToPaise('1799'),179900);});
for(const amount of ['','-5','1.001','1e3','Infinity','1,499','0'])test('rupee parser rejects '+JSON.stringify(amount),()=>assert.throws(()=>contract.rupeesToPaise(amount)));
test('new receipt SKUs preserve existing line objects/quantities/cost',()=>{const old={variantId:'old',acceptedQuantity:'9',rejectedQuantity:'2',unitCostRupees:'825'};const incoming={variantId:'new',productName:'Dress',sku:'NEW',color:'Navy',size:'M',onHand:0,imageUrl:null,photoCount:0};const result=contract.appendNewReceiptLines([old],[incoming,incoming]);assert.equal(result.length,2);assert.equal(result[0],old);assert.equal(result[1].acceptedQuantity,'');assert.equal(result[1].rejectedQuantity,'0');assert.equal(result[1].unitCostRupees,'');});
test('using the same product twice cannot duplicate a receipt line',()=>{const line={variantId:'same',acceptedQuantity:'7'};assert.deepEqual(contract.appendNewReceiptLines([line],[{variantId:'same'}]),[line]);});
test('disabled SKUs are excluded from the receipt handoff',()=>{const p=product();p.variants[0].active=false;assert.deepEqual(contract.receiveVariants(p),[]);});
test('service creates draft, nested variants and zero inventory atomically',async()=>{const f=fake();const result=await new AdminProductsService(f.db).create(valid());assert.equal(result.status,'DRAFT');assert.equal(result.variants.length,8);assert.equal(f.txCount,1);for(const v of result.variants){assert.equal(v.inventory.onHand,0);assert.equal(v.inventory.reserved,0);assert.equal(v.inventory.safetyStock,0);}assert.equal(new Set(result.variants.map(v=>v.sku)).size,8);});
test('creation replay with the same request does not create twice',async()=>{const f=fake();const service=new AdminProductsService(f.db);const first=await service.create(valid());const again=await service.create(valid());assert.equal(first.id,again.id);assert.equal(f.calls.filter(c=>c[0]==='create').length,1);});
test('creation replay with changed payload is a conflict',async()=>{const f=fake();const service=new AdminProductsService(f.db);await service.create(valid());await assert.rejects(()=>service.create({...valid(),name:'Other dress'}),expectStatus(409));});
test('unknown input is converted to HTTP 400 before transaction',async()=>{const f=fake();await assert.rejects(()=>new AdminProductsService(f.db).create({...valid(),onHand:9}),expectStatus(400));assert.equal(f.txCount,0);});
test('bad category rolls back before creating product',async()=>{const f=fake();await assert.rejects(()=>new AdminProductsService(f.db).create({...valid(),categoryId:'bad'}),expectStatus(400));assert.equal(f.saved,null);});
test('metadata editing does not reset stock or reserved quantities',async()=>{const f=fake(product());const result=await new AdminProductsService(f.db).edit(f.saved.id,{name:'Renamed Kurta',collectionIds:[],expectedUpdatedAt:version(f.saved)});assert.equal(result.name,'Renamed Kurta');assert.equal(result.slug,'meera-cotton-kurta');assert.equal(result.variants[0].inventory.onHand,9);assert.equal(result.variants[0].inventory.reserved,2);});
test('stale form cannot overwrite a more recent product',async()=>{const f=fake(product());await assert.rejects(()=>new AdminProductsService(f.db).edit(f.saved.id,{name:'Overwrite',expectedUpdatedAt:'2026-09-01T00:00:00.000Z'}),expectStatus(409));assert.equal(f.saved.name,'Meera Cotton Kurta');});
test('add variants skips existing combinations and preserves old stock',async()=>{const f=fake(product());const value={colors:[{name:'maroon'}],sizes:['M','L'],pricePaise:159900,mrpPaise:199900,expectedUpdatedAt:version(f.saved)};const result=await new AdminProductsService(f.db).addVariants(f.saved.id,value);assert.equal(result.variants.length,2);assert.equal(result.variants[0].inventory.onHand,9);assert.equal(result.variants[1].inventory.onHand,0);assert.equal(result.variants[1].color,'Maroon');assert.equal(result.variants[0].pricePaise,149900);assert.equal(result.variants[1].pricePaise,159900);});
test('adding an existing matrix reports conflict without resetting it',async()=>{const f=fake(product());await assert.rejects(()=>new AdminProductsService(f.db).addVariants(f.saved.id,{colors:[{name:'MAROON'}],sizes:['m'],pricePaise:100,mrpPaise:200,expectedUpdatedAt:version(f.saved)}),expectStatus(409));assert.equal(f.saved.variants.length,1);});
test('new size inherits existing same-colour images',async()=>{const p=product();p.variants[0].images=[{id:'img1',url:'https://example.invalid/product.jpg',alt:'Maroon front',position:0}];const f=fake(p);const result=await new AdminProductsService(f.db).addVariants(p.id,{colors:[{name:'Maroon'}],sizes:['L'],pricePaise:149900,mrpPaise:179900,expectedUpdatedAt:version(p)});assert.equal(result.variants[1].images[0].url,p.variants[0].images[0].url);});
test('archived product must return to Draft before new variants',async()=>{const p=product({status:'ARCHIVED'}),f=fake(p);await assert.rejects(()=>new AdminProductsService(f.db).addVariants(p.id,{colors:[{name:'Navy'}],sizes:['L'],pricePaise:100,mrpPaise:200,expectedUpdatedAt:version(p)}),expectStatus(400));});
test('publishing without photo is refused',async()=>{const p=product(),f=fake(p);await assert.rejects(()=>new AdminProductsService(f.db).setStatus(p.id,{status:'ACTIVE',expectedUpdatedAt:version(p)}),expectStatus(400));assert.equal(f.saved.status,'DRAFT');});
test('publishing validates at least one active SKU',async()=>{const p=product();p.variants[0].active=false;p.images=[{url:'photo'}];const f=fake(p);await assert.rejects(()=>new AdminProductsService(f.db).setStatus(p.id,{status:'ACTIVE',expectedUpdatedAt:version(p)}),expectStatus(400));});
test('publish does not invent inventory even when stock is zero',async()=>{const p=product();p.variants[0].inventory.onHand=0;p.variants[0].inventory.reserved=0;p.variants[0].images=[{url:'photo'}];const f=fake(p);const r=await new AdminProductsService(f.db).setStatus(p.id,{status:'ACTIVE',expectedUpdatedAt:version(p)});assert.equal(r.status,'ACTIVE');assert.equal(r.variants[0].inventory.onHand,0);});
test('archive keeps quantities and variants',async()=>{const p=product(),f=fake(p);const r=await new AdminProductsService(f.db).setStatus(p.id,{status:'ARCHIVED',expectedUpdatedAt:version(p)});assert.equal(r.status,'ARCHIVED');assert.equal(r.variants[0].inventory.onHand,9);assert.equal(r.variants.length,1);});
test('SKU ownership is checked before editing',async()=>{const p=product(),f=fake(p);await assert.rejects(()=>new AdminProductsService(f.db).editVariant(p.id,'foreign',{pricePaise:100,mrpPaise:200,active:true,expectedUpdatedAt:version(p)}),expectStatus(404));});
test('cannot disable SKU with reserved stock',async()=>{const p=product(),f=fake(p);await assert.rejects(()=>new AdminProductsService(f.db).editVariant(p.id,p.variants[0].id,{pricePaise:100,mrpPaise:200,active:false,expectedUpdatedAt:version(p)}),expectStatus(409));});
test('editing SKU prices does not change stock or identity',async()=>{const p=product(),f=fake(p);const r=await new AdminProductsService(f.db).editVariant(p.id,p.variants[0].id,{pricePaise:129900,mrpPaise:179900,active:true,expectedUpdatedAt:version(p)});assert.equal(r.variants[0].pricePaise,129900);assert.equal(r.variants[0].sku,p.variants[0].sku);assert.equal(r.variants[0].inventory.onHand,9);});
test('write conflicts are retried with a bounded transaction policy',async()=>{const f=fake();f.setRetries(2);await new AdminProductsService(f.db).create(valid());assert.equal(f.txCount,3);});
test('exhausted retries become HTTP 409',async()=>{const f=fake();f.setRetries(4);await assert.rejects(()=>new AdminProductsService(f.db).create(valid()),expectStatus(409));assert.equal(f.txCount,3);});
for(const value of [undefined,'wrong',['unit-test-only-hidi-key']])test('API guard rejects '+JSON.stringify(value),()=>assert.throws(()=>new AdminProductsGuard().canActivate({switchToHttp:()=>({getRequest:()=>({headers:{'x-admin-key':value}})})}),expectStatus(401)));
test('API guard accepts exact configured key',()=>assert.equal(new AdminProductsGuard().canActivate({switchToHttp:()=>({getRequest:()=>({headers:{'x-admin-key':'unit-test-only-hidi-key'}})})}),true));
test('all product endpoints have a class-level admin guard',()=>{const source=fs.readFileSync(path.join(apiPath,'admin-products.controller.ts'),'utf8');assert.match(source,/@UseGuards\(AdminProductsGuard\)\s*export class AdminProductsController/);});
function req(method='GET',body,headers={}) {const r=new Request('http://localhost:3000/api/admin/products',{method,headers:{...(method==='GET'?{}:{'content-type':'application/json'}),...headers},...(body===undefined?{}:{body:JSON.stringify(body)})});r.nextUrl=new URL(r.url);return r;}
function proxy(auth=true,fetch=async()=>Response.json({ok:true})) {const l=loader({'next/server':{NextResponse:Response},'@/lib/api':{API_URL:'http://127.0.0.1:4000/v1'},'@/lib/admin-auth':{isAdminRequest:()=>auth},fetch});return l(path.join(files,'apps/web/lib/admin-products-proxy.ts')).proxyProducts;}
test('proxy rejects missing admin session before calling API',async()=>{const r=await proxy(false)(req());assert.equal(r.status,401);});
test('proxy refuses cross-site writes',async()=>{const r=await proxy()(req('POST',{}, {'sec-fetch-site':'cross-site'}));assert.equal(r.status,403);});
test('proxy refuses wrong browser origin',async()=>{const r=await proxy()(req('POST',{}, {'origin':'https://attacker.invalid'}));assert.equal(r.status,403);});
test('proxy supports the forwarded Codespaces host',async()=>{const r=await proxy()(req('POST',{}, {'origin':'https://codespace-3000.app.github.dev','x-forwarded-host':'codespace-3000.app.github.dev'}));assert.equal(r.status,200);});
test('proxy rejects oversized JSON before forwarding',async()=>{const r=await proxy()(req('POST',{description:'x'.repeat(65537)}));assert.equal(r.status,413);});
test('proxy never returns an admin key and uses no-store',async()=>{const r=await proxy(true,async(_url,init)=>{assert.equal(init.headers['x-admin-key'],'unit-test-only-hidi-key');return Response.json({items:[]});})(req());assert.equal(r.headers.get('cache-control'),'private, no-store');assert.equal((await r.text()).includes('unit-test-only-hidi-key'),false);});
test('backend key mismatch maps to a configuration error',async()=>{const r=await proxy(true,async()=>Response.json({message:'bad key'},{status:401}))(req());assert.equal(r.status,502);});
test('all distributed TS/TSX sources pass transpilation diagnostics',()=>{let count=0;function walk(root){for(const name of fs.readdirSync(root)){const p=path.join(root,name);if(fs.statSync(p).isDirectory())walk(p);else if(/\.tsx?$/.test(p)){const result=ts.transpileModule(fs.readFileSync(p,'utf8'),{fileName:p,reportDiagnostics:true,compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX,experimentalDecorators:true,emitDecoratorMetadata:true}});assert.equal((result.diagnostics??[]).filter(d=>d.category===ts.DiagnosticCategory.Error).length,0,p);count++;}}}walk(files);assert.ok(count>=20);});
