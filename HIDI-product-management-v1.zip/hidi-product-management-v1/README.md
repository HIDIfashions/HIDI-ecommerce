# HIDI Product Management v1 — GitHub.com / Codespaces setup

Repository: `HIDIfashions/HIDI-ecommerce`
Target branch: `feature/admin-inventory`
Prerequisite: the stock-receiving/SKU-photo update and its already-applied migration.

This archive contains an installer and an application patch. It is not a replacement repository. Do not unzip its `files` directory over your project manually. No new dependencies, Prisma schema edits, database migrations, database resets, seed data or environment-variable changes are included. Product photography reuses your previously installed upload endpoint.

## What is added

A protected `/admin/products` catalogue dashboard, product creation/editing, categories, existing collection assignments, colour/size matrix generation, individual SKU price/weight/enabled edits, Draft/Active/Archived transitions, and the **Create new product** modal within Receive Stock. Product creation starts every new SKU at zero stock. The receipt modal keeps the parent form mounted and merges new variant IDs without replacing its previous quantities/costs.

The only shared application files patched are:

- `apps/api/src/admin/admin.module.ts` — import the new self-contained product module.
- `apps/web/app/admin/inventory/admin-inventory-client.tsx` — enable the Products navigation link.
- `apps/web/app/admin/inventory/receive/stock-receipt-client.tsx` — navigation link, modal shortcut, preserving merge, and photo metadata refresh.

Everything else is added under new product-specific paths and `docs/admin-products.md`. Existing schema, migrations, `.env` files, root package/lockfiles, layout, Next.js config, TypeScript config, reviews and rewards files are not overwritten. The installer only patches unique known contexts; it stops when an anchor or prerequisite is missing or a new-file path already contains different code.

## 1. Upload through GitHub.com

Choose `HIDIfashions/HIDI-ecommerce` → `feature/admin-inventory`. At the repository root, choose **Add file → Upload files**. Upload `HIDI-product-management-v1.zip` itself. Commit to this feature branch, not `main`, using a message such as:

`chore: upload product management update package`

Uploading the archive transfers code; it does not install or deploy it. Do not upload environment files or secrets.

## 2. Retrieve the package and run a read-only preflight

Open a spare terminal in the existing Codespace. This block fetches the uploaded archive without merging the branch into your working directory. It does not stash, discard or commit your current changes. Copy commands only, not a shell prompt or expected output.

```bash
cd /workspaces/HIDI-ecommerce &&
UPDATE_DIR="$(mktemp -d /tmp/hidi-products.XXXXXX)" &&
git fetch origin feature/admin-inventory &&
git show FETCH_HEAD:HIDI-product-management-v1.zip > "$UPDATE_DIR/update.zip" &&
unzip -q "$UPDATE_DIR/update.zip" -d "$UPDATE_DIR" &&
python3 "$UPDATE_DIR/hidi-product-management-v1/install.py" --repo /workspaces/HIDI-ecommerce --check
```

Expected final status: **CHECK PASSED — no files or database changed.** It also prints the exact `--apply` command with the temporary directory filled in. If preflight reports STOP, share that output and do not force an overwrite or delete any existing files.

## 3. Apply only after preflight succeeds

Stop the frontend and backend development watchers with Ctrl+C in their terminals. Keep the database running. Run the exact `python3 ... --apply` command printed by the successful preflight. You can also run this in the same terminal where UPDATE_DIR was set:

```bash
python3 "$UPDATE_DIR/hidi-product-management-v1/install.py" --repo /workspaces/HIDI-ecommerce --apply
```

The installer backs up changed shared files to a sibling `HIDI-products-backup-...` directory outside the Git repository. Its `backup.json` records which files were added and their before/after hashes. Keep this folder and the earlier stash. The installer does not use or remove either stash entry or older backup folders. Reapplying the same package is a no-op when all updates already match.

Review without staging everything:

```bash
cd /workspaces/HIDI-ecommerce &&
git diff --stat &&
git status --short
```

Do not use a blanket `git add .`: earlier configuration fixes, old ZIPs, tool folders and migrations are still mixed into this workspace. Do not run a database reset, seed, or another migration for this package.

## 4. Build checks in the Codespace

The API generated client already exists from the stock-receiving migration. This patch does not change the schema.

```bash
cd /workspaces/HIDI-ecommerce &&
pnpm --filter @hidi/api build &&
pnpm --filter @hidi/web exec next typegen &&
pnpm --filter @hidi/web exec tsc --noEmit &&
printf '\nHIDI product API build and frontend type-check passed.\n'
```

Stop on a failure. Frontend type generation plus type-checking is not a production bundle build. Run the actual frontend build before merging/deploying:

```bash
pnpm --filter @hidi/web build
```

A production Next.js build may need the project's environment settings and a reachable API for pages that fetch data while building. Do not change dependencies merely to hide an unrelated build error; retain the output for diagnosis.

## 5. Start exactly one instance of each server

Backend terminal:

```bash
cd /workspaces/HIDI-ecommerce && pnpm dev:api
```

Frontend terminal:

```bash
cd /workspaces/HIDI-ecommerce && pnpm dev:web
```

If port 4000 reports EADDRINUSE, stop the duplicate backend watcher and identify the existing listener. Do not start more copies, kill all Node processes, or change ports to mask it. The existing API rewrite remains untouched.

Open the existing frontend address with `/admin/products` appended. From Inventory and Receive Stock, the Products navigation link is now active. The receiving page also has **+ Create new product**.

## 6. Acceptance test before business use

Use clearly labelled test data in a test environment. Do not post fictitious warehouse stock into a live business ledger.

1. Create `TEST Meera Kurta`, two colours and M/L/XL/XXL. Verify eight different SKUs, DRAFT status, and zero stock/reservations.
2. Confirm the draft is absent from the customer catalogue and its public product URL is not available.
3. In Receive Stock, enter a test supplier, invoice/PO and one existing line with quantities. Open Create new product, save another test draft and use its SKUs in the receipt. Verify the original supplier, invoice, line quantities and costs are unchanged; new lines have blank accepted quantity/cost. Save the receipt as DRAFT only and verify stock stays unchanged.
4. Add an additional size to an existing product. Check only missing combinations were created and existing on-hand/reserved figures did not change. Try a duplicate combination; it must not duplicate stock.
5. Upload a correctly coloured test photo through the existing storage setup, checking all-size/per-SKU scope. Verify it in the product editor and receiving UI. Add suitable photos for each colour before publishing.
6. Publish a test product only in a test environment. Confirm visibility and colour/size/photo switching in the public product page. A zero-stock variant should not be purchasable. Move back to Draft/Archive and confirm it becomes hidden without deleting inventory.
7. Open the same product in two tabs. Save one, then save the stale other tab. Expect a conflict/reload message rather than a silent overwrite.
8. Verify unauthenticated browser/API requests cannot read or modify admin products. Verify no admin/storage key appears in client requests, console logs or Git diffs.

Clean up test data by archiving test products. This package deliberately does not provide hard-delete or automated cleanup of stock receipts.

## 7. Rerun the isolated tests (optional)

The backend already lists TypeScript as a dev dependency. In the same Codespace terminal:

```bash
node "$UPDATE_DIR/hidi-product-management-v1/tests/run-tests.cjs" --repo /workspaces/HIDI-ecommerce
python3 "$UPDATE_DIR/hidi-product-management-v1/tests/test_installer.py"
```

These use mocked database/framework boundaries and temporary files; they do not test or modify your live Supabase database. See TEST-REPORT.md for verification scope.

## Before a Git commit or merge

Application changes still live in the Codespace until reviewed and committed. GitHub may also be ahead because the ZIP was uploaded there. Inspect the remote changes and reconcile the branch only after checking they do not overwrite uncommitted feature work. Review the changed/new source paths individually, complete the full build/runtime checks, then stage only intended source/docs changes. Do not discard the stock-receiving, reviews or rewards work to obtain a clean status.

## References

- GitHub browser uploads: https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- Git fetch: https://git-scm.com/docs/git-fetch
- Git show: https://git-scm.com/docs/git-show
- Next.js route handlers: https://nextjs.org/docs/app/api-reference/file-conventions/route
- Prisma transaction isolation/retries: https://docs.prisma.io/docs/orm/v7/prisma-client/queries/transactions
- NestJS guards: https://docs.nestjs.com/guards
