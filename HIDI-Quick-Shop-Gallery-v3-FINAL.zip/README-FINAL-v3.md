# HIDI Quick-Shop Gallery v3 — Final Minimal Media UI

This is the final cleaned-up HIDI product-card gallery requested on 18 Sep 2026.

## Customer-facing behaviour

- Desktop: product photos roll automatically while the customer hovers the media area.
- Mobile/tablet: swipe left/right across the photo area to move through media.
- Product video can appear in the same sequence; it never downloads until the customer taps Play.
- Photo expand button remains at the lower-right corner.
- Clicking/tapping a photo opens an enlarged modal without leaving the collection page.
- No visible previous/next arrow buttons.
- No thumbnail/album strip.
- No "3 photos · 1 video" text.
- No "Swipe / explore" or "Tap to enlarge" line.
- No "Product media" colour-description line.
- No media counter/preview control clutter.
- Existing colour, size, Add to Bag, wishlist, price, stock and Details behaviour is preserved.

## Files in this package

Copy the `files/` directory into the repository root, preserving paths.

Key changed files:

- `apps/web/components/product-card-media.tsx`
- `apps/web/components/product-card-media.module.css`
- `apps/web/components/product-card.tsx`

The other v2 files remain included because this is a self-contained final package.

## Recommended branch

Create/use:

`feature/storefront-media-gallery`

Base it on your current HIDI working branch that already contains the inventory and quick-shop work.

## Manual install in Codespaces

```bash
cd /workspaces/HIDI-ecommerce
unzip HIDI-Quick-Shop-Gallery-v3-FINAL.zip -d /tmp/hidi-gallery-v3
cp -R /tmp/hidi-gallery-v3/files/* .

pnpm --filter @hidi/web exec tsc --noEmit
pnpm --filter @hidi/web build
(cd apps/api && pnpm build)

git diff --check
git status --short
```

Then test the collection page on desktop and mobile before committing.

## Suggested commit

```bash
git add apps/web/components/product-card-media.tsx \
        apps/web/components/product-card-media.module.css \
        apps/web/components/product-card.tsx \
        apps/web/lib/product-card-media-utils.ts \
        apps/web/lib/product-card-videos.ts \
        apps/web/lib/product-card-utils.ts \
        apps/web/lib/catalog-cart.ts \
        apps/web/components/product-card.module.css \
        apps/web/components/wishlist-page-client.tsx \
        apps/api/src/products/products.service.ts

git commit -m "feat(storefront): simplify quick-shop media gallery"
git push -u origin feature/storefront-media-gallery
```
