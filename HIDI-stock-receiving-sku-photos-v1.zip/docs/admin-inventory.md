# HIDI admin inventory

The inventory workspace is available at `/admin/inventory` and uses the same secure admin session as `/admin/orders`.

## Stock rules

- Inventory is stored for every SKU, so each colour and size has its own quantity.
- **On hand** is the physical warehouse quantity.
- **Reserved** is managed by checkout and cannot be edited manually.
- **Ready to sell = on hand - reserved - safety stock**.
- A variant is low when physical available stock reaches its configured reorder level.
- An adjustment cannot reduce stock below pieces already reserved by customers.

## First-time setup

Use the same `ADMIN_API_KEY` value in `apps/web/.env.local` and `apps/api/.env`, then run:

```bash
pnpm db:generate
pnpm db:migrate
pnpm dev
```

The migrations add `reorderLevel`, the inventory movement audit trail, goods receipts and SKU-level product images. Manual adjustments and posted receipts record the before/after quantity, reference, note and operator.

## Warehouse workflow

1. Open `/admin/inventory` and use the existing admin key.
2. Search for a product, SKU or colour.
3. Select **Adjust** on the exact size/colour variant.
4. Choose **Receive**, **Remove** or **Set exact**.
5. Enter the quantity, reason and purchase-order reference.
6. Confirm the projected stock and save.

Checkout reservations and paid-order stock deductions continue through the existing commerce services.

## Receiving a manufacturer delivery

Use `/admin/inventory/receive` for normal inbound stock. It creates one goods receipt for multiple SKUs.

1. Add the supplier, received date and invoice or purchase-order number.
2. Search for each existing SKU and add it to the receipt.
3. Enter accepted pieces, rejected pieces and the unit cost.
4. Optionally upload the product photography for that SKU. **Use for all colour sizes** shares the image with every size of the same product and colour.
5. Choose **Save draft** to record the delivery without changing stock, or **Confirm & post receipt** to add accepted pieces to on-hand inventory.

Rejected pieces are recorded for quality reporting but never become sellable stock. Posting is idempotent: pressing Post again does not receive the same goods twice.

## SKU photo storage

Create a **public** Supabase Storage bucket named `hidi-products`. In `apps/web/.env.local`, configure:

```bash
SUPABASE_URL=https://your-project-ref.supabase.co
SUPABASE_SECRET_KEY=sb_secret_...
SUPABASE_PRODUCT_IMAGES_BUCKET=hidi-products
```

`SUPABASE_SECRET_KEY` is server-only. Never add `NEXT_PUBLIC_` to it, commit it, paste it into the browser, or show it in a screenshot. The browser sends the photo only to HIDI's authenticated admin route; that server route uploads to Storage and saves the public URL against the SKU.

Allowed formats are JPEG, PNG, WebP and AVIF, up to 8 MB per image. On the storefront, the product page switches to SKU photos when the shopper chooses a colour or size. Product-level photos remain the fallback when a SKU has none. The cart, account orders and order-confirmation screens also prefer the selected SKU photo.
